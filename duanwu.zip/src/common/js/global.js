import {setparam} from "./base";
const url = window.location.href
const str = 't'
const t = setparam(url,str)
export default {
	t
}
