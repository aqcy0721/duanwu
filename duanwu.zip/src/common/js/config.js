export const HEIGHT = {
  header: '0.98'
}
